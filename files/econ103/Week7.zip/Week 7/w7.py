import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.pyplot import figure

x = np.linspace(0, 100, 1000)
epsilon = np.random.normal(0,1,1000)

y = 100 + 10*x + 2*x*epsilon
yh = 100 + 10*x
figure(num=None, figsize=(8, 6), dpi=400, facecolor='w', edgecolor='k')
plt.scatter(y,x)
plt.plot(yh,x,color = 'red', label = 'Regression Line')
plt.title('Income vs. Age')
plt.xlabel('Age')
plt.ylabel('Income')
plt.legend(loc = 'best')
plt.savefig('ex1.png')
