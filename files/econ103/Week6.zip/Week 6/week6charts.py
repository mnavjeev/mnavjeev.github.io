import pandas as pd
import numpy as np
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt
import statsmodels.api as sm
import operator
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import PolynomialFeatures
from scipy.stats import ttest_ind
import seaborn as sns
from scipy import stats
figure(num=None, figsize=(14, 10), dpi=500, facecolor='w', edgecolor='k')

x2 = np.random.uniform(low = 0, high = 10, size = 200)
e2 = 8*np.random.normal(size = 200)
y2 = 3 + 2.5*x2 + e2

x = np.random.uniform(low = 0, high = 10, size = 200)
e = 8*np.random.normal(size = 200)
y = 3 + 2.5*x + e
yTrue = 3 + 2.5*x
figure(num=None, figsize=(14, 10), dpi=500, facecolor='w', edgecolor='k')
plt.scatter(x,y)
#plt.scatter(x2,y2, color = "darkgrey")
plt.plot(x,yTrue , color = "red", label = "True Relationship")
plt.plot(z, yHat, color = "green", label = "Fitted 10th Order Polynomial")
plt.legend(loc = "best")
plt.xlabel("X")
plt.ylabel("Y")
plt.title("In Sample Fit of 10th Order Polynomial")
plt.savefig("In Sample")


x0 = x**0
x2 = x**2
x3 = x**3
x4 = x**4
x5 = x**5
x6 = x**6
x7 = x**7
x8 = x**8
x9 = x**9
x10 = x**10
data = pd.DataFrame(np.transpose([y,x0,x,x2,x3,x4, x5, x6, x7, x8, x9, x10]))
Y = data[0]
X = data[[1,2,3,4,5,6,7,8,9,10,11]]
model = sm.OLS(Y, X).fit()

z = np.linspace(0,10, 1000)
z0 = z**0
z2 = z**2
z3 = z**3
z4 = z**4
z5 = z**5
z6 = z**6
z7 = z**7
z8 = z**8
z9 = z**9
z10 = z**10
data2 = pd.DataFrame(np.transpose([z0,z,z2,z3,z4,z5,z6,z7,z8,z9,z10]))
yHat = model.predict(data2)
