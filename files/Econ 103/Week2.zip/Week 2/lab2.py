import pandas as pd
import numpy as np
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn import metrics

x = np.linspace(0,50,1000)
y = 2 + x + 4*x**2 + 300*np.random.randn(1000)

model = LinearRegression()
model.fit(x.reshape(-1,1),y.reshape(-1,1))
alpha = model.intercept_[0]
beta = model.coef_[0]
alpha
beta

figure(num=None, figsize=(8, 6), dpi=400, facecolor='w', edgecolor='k')
plt.scatter(x,y, label = 'Data')
plt.xlabel("X")
plt.ylabel("Y")
plt.plot(x, alpha + beta*x, color = 'darkgreen', label = 'Fitted Simple OLS Line')
plt.legend(loc = 'best')
plt.title('Trying to Fit a Linear Model to Quadratic Data')
plt.savefig('ex_quad')
