import pandas as pd
import numpy as np
from matplotlib.pyplot import figure
import matplotlib.pyplot as plt
import seaborn as sns

age = np.linspace(18, 65, 100)
earnings = 1000 + 900*age + 8500*np.random.randn(100)
eh = 900*age + 1000



figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
plt.scatter(age, earnings)
plt.xlabel('age')
plt.ylabel('earnings')
plt.title("Scatter Plot of Age vs. Earnings")
plt.savefig('scatter1.png')

figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
plt.scatter(age, earnings)
plt.plot(age, eh, color = 'green', label = ' Fitted Regression Line; \n alpha = 1000 \n beta = 900')
plt.xlabel('age')
plt.ylabel('earnings')
plt.legend(loc = 'best')
plt.title("Fitted Regression Line of Age vs. Earnings")
plt.savefig('scatter2.png')

errors = earnings - eh
figure(num=None, figsize=(8, 6), dpi=400, facecolor='w', edgecolor='k')
sns.distplot(errors)
plt.xlabel("Errors")
plt.title('Histogram of Errors')
plt.ylabel('Frequency')
plt.savefig('errors.png')



figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
plt.scatter(np.linspace(0,100, 100),errors)
plt.axhline(y=0.5, color='black')
plt.title('Residuals Plot for Age vs. Earnings')
plt.xlabel('Index')
plt.ylabel('Residuals')
plt.savefig('residuals.png')

#Book Problems
p1x = np.linspace(0, 100, 1000)
p1y = -240 + 8*p1x
figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
plt.plot(p1x, p1y)
plt.xlabel('Temperature (Degrees Farenheit)')
plt.ylabel('Estimated Sodas Sold')
plt.title('Plot of regression line y = -240 + 8x')
plt.savefig('prob1.png')
